package com.extrc.services;

import com.extrc.models.KnowledgeBase;

public interface KnowledgeBaseService {

  public KnowledgeBase getKnowledgeBase();

}
