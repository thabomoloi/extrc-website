package com.extrc.services;

import org.tweetyproject.logics.pl.syntax.PlFormula;

public interface FormulaService {
  public PlFormula getQueryFormula();
}
